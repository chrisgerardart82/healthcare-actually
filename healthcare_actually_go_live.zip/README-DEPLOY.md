# Healthcare Actually — deployment guide

This is the LIVE BACKEND edition, not the static-only demo. It contains per-episode interactive activities and a persistent shared leaderboard, and submits guest questions to a private Netlify Blobs store.

## Deploying to the existing Netlify site

**Use Netlify Git-based deployment or the Netlify CLI. Do not drag and drop just index.html or this ZIP into Netlify Drop:** static-only drag-and-drop deployment will not deploy the Netlify Function.

1. Put all of these files in a GitHub repository (preserving `netlify/functions/community.mjs`).
2. Open Netlify > your existing site > Project configuration > Build & deploy > Continuous deployment, and link the repository.
3. Build command: `npm install` (Netlify installs dependencies automatically in a Git build); publish directory: `.`; functions directory: `netlify/functions`.
4. Deploy, then test `https://YOURDOMAIN/.netlify/functions/community?episode=finance` and confirm it responds with JSON `{"leaders":[]}`.
5. On the site, choose an episode, take the Challenge and set a name. Refresh another browser to confirm the score appears for that episode. Submit a guest question.

Alternatively, after installing Node and the Netlify CLI locally, from this folder run `npm install`, `npx netlify login`, `npx netlify link`, then `npx netlify deploy --prod --dir=. --functions=netlify/functions`. Choose the existing site at the link stage.

## Editorial submissions

Q&A questions go into the private Netlify Blobs store `ha-editorial-questions-v1` under keys prefixed with episode IDs. They are not publicly visible. A private admin dashboard, guest answers, and notification emails are not included. To view the submissions, use an authenticated Netlify Blobs management script or build an admin tool. Do not publish a public question-listing endpoint.

## Limits before broad public promotion

- User IDs are anonymous and stored in each visitor browser. Clearing storage loses identity, and one person can use multiple browsers.
- Points are granted once per activity per device in UI and once per visitor ID in backend. The server cannot cryptographically verify real completion without accounts and anti-abuse protection.
- Large traffic sites should move leaderboard storage to a transactional database and add CAPTCHA, rate limiting, moderation and login.
- The existing episode audio and follow controls still need real podcast/feed links once media is published. No audio files or guests' recorded replies were supplied.
- Netlify Blobs are account-backed when running on Netlify; the function does not work as a static file opened locally.
